	<?php
	/**
	 * Created by PhpStorm.
	 * User: your name
	 * Date: todays date
	 * Time: todays time
	 */

	define('DIR', '../');
	require_once DIR . 'config.php';

	$control = new Controller(); 
	$admin = new Admin();
	$admin->notLogged('admin', '../index'); ?>


	<!doctype html>
	<html lang="en">
	<head>
	    <meta charset="UTF-8">
	    <meta name="viewport"
	          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	    <meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title><?= SITE_TITLE; ?></title>
		<?php $control->getCSS(DIR); ?>
	</head>
	<body>
		<div id="wrapper">
			
			<?php $control->getHead(DIR); ?>

			<?php $control->getSidebar(DIR); ?>

			<div class="content-page">

	                <!-- Start content -->
	                <div class="content">
	                    <div class="container-fluid">

	                        <div class="row">
	                            <div class="col-12">
	                            	<?php $control->sessionMessage(); ?>
	                                <div class="page-title-box">
	                                    <h4 class="page-title float-left">Welcome !</h4>

	                                    <ol class="breadcrumb float-right">
	                                        <li class="breadcrumb-item"><a href="#">Gym</a></li>
	                                        
	                                        <li class="breadcrumb-item active">Dashboard </li>
	                                    </ol>

	                                    <div class="clearfix"></div>
	                                </div>
	                            </div>
	                        </div>
	                        <!-- end row -->

	                     <!-- Write the Code From Here -->





	                    </div> <!-- container -->

	                </div> <!-- content -->

	                <footer class="footer text-right">
	                    2015 - 2018 © Gym 
	                </footer>

	            </div>

		</div>

	<?php $control->getJS(DIR); ?>
	</body>
	</html>