<?php
/**
 * Created by PhpStorm.
 * User: your name
 * Date: todays date
 * Time: todays time
 */
define('DIR', '');
require_once DIR . 'config.php';

$control = new Controller(); 
$control->isLogged('admin', 'admin/index'); 
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Home</title>
	<?php $control->getCSS(DIR); ?>
</head>
<body class="pb-0">
	<div class="wrapper-page">
                <div class="account-pages">
                    <div class="account-box">
                        <div class="account-logo-box bg-primary p-4">
                            <h3 class="m-0 text-center text-white">Gym Management</h3>
                        </div>
                        <div class="account-content">
                            <form class="form-horizontal" action="#">
                            	<?php $control->sessionMessage(); ?>
                                <div class="form-group  mb-4 row">
                                    <div class="col-12">
                                        <label for="emailaddress">User Name :</label>
                                        <input class="form-control" name="user" type="text"  required="" placeholder="Enter User Name">
                                    </div>
                                </div>

                                <div class="form-group row mb-4">
                                    <div class="col-12">
                                        <label for="password">Password :</label>
                                        <input class="form-control" type="password" required="" name="password" id="password" placeholder="Enter your password">
                                    </div>
                                </div>

                                

                                <div class="form-group row text-center m-t-10">
                                    <div class="col-12">
                                        <button class="btn btn-md btn-block btn-primary waves-effect waves-light" type="submit">Sign In</button>
                                    </div>
                                </div>

                            </form>

                            

                        </div>
                    </div>
                </div>
                <!-- end account-box-->


            </div>

<?php $control->getJS(DIR); ?>


</body>
</html>