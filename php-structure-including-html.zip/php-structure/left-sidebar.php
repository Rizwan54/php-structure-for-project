<div class="left side-menu">
                <div class="slimscroll-menu" id="remove-scroll">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu" id="side-menu">
                            <li class="menu-title">Navigation</li>
                            <li>
                                <a href="index.php">
                                    <i class="ion-md-speedometer"></i> <span> Dashboard </span>
                                </a>
                            </li>

                            <li>
                                <a href="view_users.php">
                                    <i class="ion-md-basket"></i> <span> Users </span>
                                </a>
                            </li>

                            <li>
                                <a href="view_trainers.php">
                                    <i class="ion-ios-apps"></i> <span> Trainers </span>
                                </a>
                            </li>

                             <li>
                                <a href="view_foods.php">
                                    <i class="ion-md-paper"></i> <span> Foods </span>
                                </a>
                            </li>
                         

                            <li>
                                <a href="view_packages.php">
                                    <i class="ion-md-paper"></i> <span> Packages </span>
                                </a>
                            </li>

                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>