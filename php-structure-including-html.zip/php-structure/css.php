<link rel="shortcut icon" href="<?= BASE_URL; ?>assets/images/favicon.ico">

<!-- App css -->
<link href="<?= BASE_URL; ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?= BASE_URL; ?>assets/css/icons.css" rel="stylesheet" type="text/css" />
<link href="<?= BASE_URL; ?>assets/css/metismenu.min.css" rel="stylesheet" type="text/css" />
<link href="<?= BASE_URL; ?>assets/css/app.css" rel="stylesheet" type="text/css" />
<!-- your custom css -->
<link href="<?= BASE_URL; ?>assets/css/style.css" rel="stylesheet" type="text/css" />


<!--Morris Chart CSS -->
<link rel="stylesheet" href="<?= BASE_URL; ?>plugins/morris/morris.css">

<!-- sweet alerts -->
<link href="<?= BASE_URL; ?>plugins/sweet-alert2/sweetalert2.min.css" rel="stylesheet">

<!-- DataTables -->
<link href="<?= BASE_URL; ?>plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="<?= BASE_URL; ?>plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<!-- Responsive datatable examples -->
<link href="<?= BASE_URL; ?>plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />